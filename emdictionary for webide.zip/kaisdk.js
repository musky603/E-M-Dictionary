window.addEventListener('load', function(){
	
	showAd(); /* KaiAds */
});

/**
 * KaiAds
 */
var adVisible = false;
function showAd () {
	getKaiAd({
		publisher: '7f97eeb0-0a6b-4e8a-bd12-0164c5a14eed',
		app: 'EMDictionary',
		slot: 'emdict',
		timeout: '6000',
		test: 0,  
		
		onerror: err => console.error('KaiAds error catch:', err),
		onready: ad => {
			ad.call('display');
			ad.on('click', () => console.log('ad clicked') )
			ad.on('close', discardAd )
			ad.on('display', displayAd)
		}
	});
};

function displayAd () {
	console.log('ad displayed');
	adVisible = true; /* do something, like pause the game */
}
// press ESC on PC
function discardAd () {
	console.log('ad closed');
	setTimeout(function(){adVisible = false;}, 200); /* discard with a delay */
}