

var button = document.querySelector('#close');
var back = document.querySelector('#back');

function backWin() {
  window.location.replace('./index.html');
};
back.addEventListener('click', backWin);

function closeWin() {
  window.close();
};
button.addEventListener('click', closeWin);



//window.onkeydown = function(e) {
	
	//if(e.keyCode == 8  && e.target == document.body)
		
                //e.preventDefault();
		//e.stopImmediatePropagation();
	
//}

//window.addEventListener('keydown', function(e) {
   //switch(e.key) {
    
     //case 'SoftRight': 
	 
	  // window.close();
       
      // break;
	   
	   //case 'SoftLeft': 
	 
	   //window.location.replace('./index.html');
       
      // break;
	   
	   
    
   //}})
   
   
  
  
