window.addEventListener('keydown', function(e) {
   switch(e.key) {
    
     
     case 'SoftLeft': //exit

	   window.close();
         
       
       break;
	   
    
   }})
  
